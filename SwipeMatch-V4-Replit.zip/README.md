# SwipeMatch V4 — Replit + Firebase

A production-oriented Tinder-style dating app foundation built with React, Vite and Firebase.

## Included

- Email/password signup and login
- Forgot password
- 18+ age gate
- Google sign-in
- Real Firestore profiles
- Profile photo upload to Firebase Storage
- Discover / Like / Pass / Super Like
- Mutual-like matching
- Real-time chat
- Edit profile
- Block and report
- Search/filter controls
- Match list
- Responsive mobile-first UI
- Firebase security rules
- Basic admin dashboard foundation
- PWA-style mobile shell

## 1. Run on Replit

Create a new Replit app using a Node/React/Vite template, or import this ZIP.

Run:

```bash
npm install
npm run dev
```

Replit normally detects the Vite server automatically.

## 2. Create Firebase project

In Firebase Console:

1. Create a project.
2. Add a Web App.
3. Enable Authentication:
   - Email/Password
   - Google
4. Create Firestore Database.
5. Create Storage.
6. Add your Replit domain to Authentication > Settings > Authorized domains.

Copy the Firebase web configuration into Replit Secrets using the names from `.env.example`.

## 3. Firestore rules

Publish `firebase/firestore.rules`.

## 4. Storage rules

Publish `firebase/storage.rules`.

## 5. Firestore indexes

If Firebase asks for an index for a query, create the suggested index in the Firebase Console. The exact index can vary with your data/query plan.

## 6. Admin

The `/admin` route is intentionally a UI foundation. Do NOT rely on a client-side email check for real moderation permissions.

For production, create an Admin custom claim with Firebase Admin SDK / Cloud Functions and enforce it in Firestore rules. The current rules keep reports private from ordinary clients.

## 7. Important production work

Before accepting real users, add:

- Firebase App Check
- Cloud Functions/server-side admin actions
- Proper admin custom claims
- Rate limiting / abuse controls
- Stronger photo/content moderation
- Account deletion workflow
- Privacy Policy and Terms
- Age/identity verification where legally required
- Reporting escalation and audit logs
- Push notifications
- Payment provider for subscriptions
- Security testing
- Backups/monitoring

This project is a functional V4 foundation, not a guarantee of legal or production compliance.
