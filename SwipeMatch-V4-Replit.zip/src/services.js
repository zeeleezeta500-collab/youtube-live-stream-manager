import {
  collection, doc, getDoc, getDocs, setDoc, addDoc, query, where,
  orderBy, limit, onSnapshot, serverTimestamp, writeBatch
} from "firebase/firestore";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signInWithPopup, sendPasswordResetEmail, signOut, updateProfile
} from "firebase/auth";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage, googleProvider } from "./firebase";

export async function register({name, email, password, age, city, gender}) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(cred.user, {displayName: name});
  await setDoc(doc(db, "users", cred.user.uid), {
    uid: cred.user.uid, name, email, age: Number(age), city: city || "",
    gender: gender || "", bio: "", photoURL: "", createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return cred.user;
}
export async function login(email, password) {
  return (await signInWithEmailAndPassword(auth, email, password)).user;
}
export async function googleLogin() {
  const cred = await signInWithPopup(auth, googleProvider);
  const refUser = doc(db, "users", cred.user.uid);
  const snap = await getDoc(refUser);
  if (!snap.exists()) {
    await setDoc(refUser, {
      uid: cred.user.uid, name: cred.user.displayName || "New User",
      email: cred.user.email || "", age: 18, city: "", gender: "",
      bio: "", photoURL: cred.user.photoURL || "", createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }
  return cred.user;
}
export const logout = () => signOut(auth);
export const resetPassword = email => sendPasswordResetEmail(auth, email);

export async function getProfile(uid) {
  const s = await getDoc(doc(db, "users", uid));
  return s.exists() ? s.data() : null;
}
export async function saveProfile(uid, data) {
  await setDoc(doc(db, "users", uid), {...data, uid, updatedAt: serverTimestamp()}, {merge:true});
}
export async function uploadPhoto(uid, file) {
  const path = `profilePhotos/${uid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file, {contentType: file.type});
  return getDownloadURL(storageRef);
}

export async function discoverProfiles(currentUid) {
  const [usersSnap, blocksSnap, likesSnap] = await Promise.all([
    getDocs(query(collection(db, "users"), limit(100))),
    getDocs(query(collection(db, "blocks"), where("from", "==", currentUid))),
    getDocs(query(collection(db, "likes"), where("from", "==", currentUid)))
  ]);
  const blocked = new Set(blocksSnap.docs.map(d => d.data().to));
  const acted = new Set(likesSnap.docs.map(d => d.data().to));
  return usersSnap.docs.map(d=>d.data())
    .filter(u => u.uid !== currentUid && !blocked.has(u.uid) && !acted.has(u.uid))
    .filter(u => Number(u.age) >= 18);
}

export async function passUser(from, to) {
  await setDoc(doc(db, "likes", `${from}_${to}`), {
    from, to, type: "pass", createdAt: serverTimestamp()
  });
}

export async function likeUser(from, to, type="like") {
  await setDoc(doc(db, "likes", `${from}_${to}`), {
    from, to, type, createdAt: serverTimestamp()
  });
  if (type === "pass") return null;
  const reverse = await getDoc(doc(db, "likes", `${to}_${from}`));
  if (!reverse.exists() || !["like","super"].includes(reverse.data().type)) return null;
  const matchId = [from,to].sort().join("_");
  await setDoc(doc(db, "matches", matchId), {
    id: matchId, users: [from,to].sort(), createdAt: serverTimestamp(), lastMessage: ""
  }, {merge:true});
  return matchId;
}

export async function blockUser(from, to) {
  await setDoc(doc(db, "blocks", `${from}_${to}`), {
    from, to, createdAt: serverTimestamp()
  });
}

export async function reportUser(reporterId, reportedId, reason) {
  await addDoc(collection(db, "reports"), {
    reporterId, reportedId, reason, status:"open", createdAt: serverTimestamp()
  });
}

export function listenMatches(uid, cb) {
  const q = query(collection(db, "matches"), where("users", "array-contains", uid));
  return onSnapshot(q, snap => cb(snap.docs.map(d=>d.data())));
}

export async function getOtherProfile(match, uid) {
  const other = match.users.find(id=>id!==uid);
  return getProfile(other);
}

export function listenMessages(matchId, cb) {
  const q = query(collection(db, "matches", matchId, "messages"), orderBy("createdAt","asc"), limit(200));
  return onSnapshot(q, snap => cb(snap.docs.map(d=>({id:d.id,...d.data()}))));
}

export async function sendMessage(matchId, senderId, text) {
  const clean = text.trim();
  if (!clean) return;
  await addDoc(collection(db, "matches", matchId, "messages"), {
    senderId, text: clean, createdAt: serverTimestamp()
  });
  await setDoc(doc(db, "matches", matchId), {
    lastMessage: clean, lastMessageAt: serverTimestamp()
  }, {merge:true});
}