import React, {useEffect, useMemo, useState} from "react";
import {onAuthStateChanged} from "firebase/auth";
import {
  Heart, X, Star, MessageCircle, User, Settings, LogOut, MapPin,
  ShieldAlert, Pencil, Search, ArrowLeft, Send, Camera, LockKeyhole
} from "lucide-react";
import {auth} from "./firebase";
import * as api from "./services";

const demoProfiles = [
  {uid:"demo1", name:"Aarav", age:25, city:"Mumbai", gender:"Male", bio:"Coffee, travel and weekend drives.", photoURL:"https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=900&q=85"},
  {uid:"demo2", name:"Maya", age:24, city:"Delhi", gender:"Female", bio:"Music lover and foodie.", photoURL:"https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=900&q=85"},
  {uid:"demo3", name:"Kabir", age:27, city:"Bengaluru", gender:"Male", bio:"Fitness, coding and road trips.", photoURL:"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=900&q=85"}
];

function AuthScreen(){
  const [mode,setMode]=useState("login");
  const [form,setForm]=useState({name:"",email:"",password:"",age:"",city:"",gender:""});
  const [busy,setBusy]=useState(false); const [error,setError]=useState("");
  const change=e=>setForm({...form,[e.target.name]:e.target.value});
  async function submit(e){
    e.preventDefault(); setError("");
    try {
      setBusy(true);
      if(mode==="signup"){
        if(Number(form.age)<18) throw new Error("You must be 18 or older.");
        await api.register(form);
      } else await api.login(form.email,form.password);
    } catch(err){setError(err.message||"Something went wrong.");}
    finally{setBusy(false)}
  }
  async function google(){try{await api.googleLogin()}catch(e){setError(e.message)}}
  async function forgot(){
    if(!form.email) return setError("Enter your email first.");
    try{await api.resetPassword(form.email); setError("Password reset email sent.")}catch(e){setError(e.message)}
  }
  return <div className="auth-shell"><div className="auth-card">
    <div className="logo">♥ <span>SwipeMatch</span></div>
    <p className="muted">Meet people. Match. Chat.</p>
    <form onSubmit={submit} className="form">
      {mode==="signup" && <>
        <input name="name" placeholder="Name" value={form.name} onChange={change} required/>
        <input name="age" type="number" min="18" placeholder="Age (18+)" value={form.age} onChange={change} required/>
        <input name="city" placeholder="City" value={form.city} onChange={change}/>
        <select name="gender" value={form.gender} onChange={change}><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select>
      </>}
      <input name="email" type="email" placeholder="Email" value={form.email} onChange={change} required/>
      <input name="password" type="password" placeholder="Password" value={form.password} onChange={change} required/>
      {error && <div className="notice">{error}</div>}
      <button className="primary" disabled={busy}>{busy?"Please wait…":mode==="signup"?"Create account":"Log in"}</button>
    </form>
    <button className="google" onClick={google}>Continue with Google</button>
    {mode==="login" && <button className="link" onClick={forgot}>Forgot password?</button>}
    <div className="switch">{mode==="login"?"New here?":"Already have an account?"} <button className="link" onClick={()=>{setMode(mode==="login"?"signup":"login");setError("")}}>{mode==="login"?"Create account":"Log in"}</button></div>
  </div></div>
}

function ProfileEditor({profile,onSave,onClose}){
  const [p,setP]=useState(profile||{}); const [saving,setSaving]=useState(false); const [error,setError]=useState("");
  async function save(e){e.preventDefault();setSaving(true);try{await api.saveProfile(p.uid,p);onSave(p);onClose()}catch(e){setError(e.message)}finally{setSaving(false)}}
  async function photo(e){const f=e.target.files?.[0];if(!f)return;try{const url=await api.uploadPhoto(p.uid,f);setP({...p,photoURL:url})}catch(e){setError(e.message)}}
  return <div className="modal"><div className="modal-card"><div className="row between"><h2>Edit profile</h2><button className="icon" onClick={onClose}>×</button></div>
    <div className="photo-edit"><img src={p.photoURL||"https://placehold.co/180x180?text=Photo"}/><label className="upload"><Camera size={18}/> Change photo<input type="file" accept="image/*" onChange={photo}/></label></div>
    <form onSubmit={save} className="form">
      <input value={p.name||""} onChange={e=>setP({...p,name:e.target.value})} placeholder="Name" required/>
      <input value={p.age||""} onChange={e=>setP({...p,age:Number(e.target.value)})} type="number" min="18" placeholder="Age" required/>
      <input value={p.city||""} onChange={e=>setP({...p,city:e.target.value})} placeholder="City"/>
      <textarea value={p.bio||""} onChange={e=>setP({...p,bio:e.target.value})} placeholder="About me" rows="4"/>
      {error&&<div className="notice">{error}</div>}<button className="primary" disabled={saving}>{saving?"Saving…":"Save profile"}</button>
    </form>
  </div></div>
}

function Discover({uid,profile}){
  const [cards,setCards]=useState([]); const [index,setIndex]=useState(0); const [message,setMessage]=useState("");
  const load=async()=>{setCards(await api.discoverProfiles(uid));setIndex(0)};
  useEffect(()=>{load()},[uid]);
  const current=cards[index];
  async function act(type){
    if(!current)return;
    try{const match=await api.likeUser(uid,current.uid,type); if(match)setMessage(`It's a match with ${current.name}!`); setIndex(i=>i+1)}
    catch(e){setMessage(e.message)}
  }
  async function report(){
    if(!current)return; const reason=prompt("Reason for report?"); if(!reason)return;
    await api.reportUser(uid,current.uid,reason); await api.blockUser(uid,current.uid);
    setMessage("User reported and blocked."); setIndex(i=>i+1);
  }
  if(!current)return <div className="empty"><Heart size={42}/><h2>No more profiles</h2><p>Check back later for new people.</p><button className="secondary" onClick={load}>Refresh</button></div>
  return <div className="discover">
    <div className="profile-card">
      <img src={current.photoURL||"https://placehold.co/900x1100?text=Profile"} />
      <div className="gradient"></div>
      <div className="profile-info"><h1>{current.name}, {current.age}</h1><div className="city"><MapPin size={16}/>{current.city||"Nearby"}</div><p>{current.bio||"No bio yet."}</p></div>
      <button className="report" onClick={report}><ShieldAlert size={17}/></button>
    </div>
    <div className="actions">
      <button className="action pass" onClick={()=>act("pass")}><X/></button>
      <button className="action super" onClick={()=>act("super")}><Star/></button>
      <button className="action like" onClick={()=>act("like")}><Heart fill="currentColor"/></button>
    </div>
    {message&&<div className="notice">{message}</div>}
  </div>
}

function Matches({uid,onChat}){
  const [matches,setMatches]=useState([]); const [profiles,setProfiles]=useState({});
  useEffect(()=>api.listenMatches(uid, async ms=>{setMatches(ms);const ps={};for(const m of ms){const p=await api.getOtherProfile(m,uid);if(p)ps[p.uid]=p}setProfiles(ps)}),[uid]);
  return <div className="panel"><h2>Your matches</h2>{matches.length===0?<div className="empty"><MessageCircle/><p>Your matches will appear here.</p></div>:matches.map(m=>{const p=profiles[m.users.find(x=>x!==uid)];return p?<button className="match-row" key={m.id} onClick={()=>onChat(m,p)}><img src={p.photoURL||"https://placehold.co/100x100?text=🙂"}/><div><b>{p.name}, {p.age}</b><span>{m.lastMessage||"Say hello 👋"}</span></div><MessageCircle/></button>:null})}</div>
}

function Chat({uid,match,person,onBack}){
  const [msgs,setMsgs]=useState([]); const [text,setText]=useState("");
  useEffect(()=>api.listenMessages(match.id,setMsgs),[match.id]);
  async function send(e){e.preventDefault();if(!text.trim())return;await api.sendMessage(match.id,uid,text);setText("")}
  return <div className="chat"><div className="chat-head"><button className="icon" onClick={onBack}><ArrowLeft/></button><img src={person.photoURL||"https://placehold.co/60x60"}/><div><b>{person.name}</b><small>{person.city||"SwipeMatch"}</small></div></div>
    <div className="messages">{msgs.map(m=><div key={m.id} className={"bubble "+(m.senderId===uid?"mine":"theirs")}>{m.text}</div>)}</div>
    <form className="composer" onSubmit={send}><input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message…"/><button className="primary icon"><Send/></button></form>
  </div>
}

function Profile({profile,onEdit,onLogout}){
  return <div className="panel profile-page"><img className="big-avatar" src={profile.photoURL||"https://placehold.co/300x300?text=Photo"}/><h1>{profile.name}, {profile.age}</h1><p className="muted">{profile.city}</p><p>{profile.bio||"Add a bio to tell people about yourself."}</p><button className="secondary wide" onClick={onEdit}><Pencil size={17}/> Edit profile</button><button className="danger wide" onClick={onLogout}><LogOut size={17}/> Log out</button></div>
}

function Admin(){
  return <div className="panel"><h2>Admin dashboard</h2><div className="notice"><LockKeyhole size={18}/> Admin UI is a foundation. Enforce admin access with Firebase custom claims before production.</div><p>Use Firebase Console / server-side Admin SDK for moderation, user management, report review and audit logs.</p></div>
}

function App(){
  const [user,setUser]=useState(null); const [profile,setProfile]=useState(null); const [tab,setTab]=useState("discover");
  const [editing,setEditing]=useState(false); const [chat,setChat]=useState(null); const [loading,setLoading]=useState(true);
  useEffect(()=>onAuthStateChanged(auth,async u=>{setUser(u);if(u){setProfile(await api.getProfile(u.uid))}else setProfile(null);setLoading(false)}),[]);
  if(loading)return <div className="loading">Loading SwipeMatch…</div>;
  if(!user)return <AuthScreen/>;
  if(!profile)return <div className="loading">Creating your profile…</div>;
  if(chat)return <Chat uid={user.uid} match={chat.match} person={chat.person} onBack={()=>setChat(null)}/>;
  return <div className="app-shell"><header><div className="logo">♥ <span>SwipeMatch</span></div><div className="header-actions"><button className="icon" onClick={()=>setEditing(true)}><Settings/></button></div></header>
    <main>
      {tab==="discover"&&<Discover uid={user.uid} profile={profile}/>}
      {tab==="matches"&&<Matches uid={user.uid} onChat={(match,person)=>setChat({match,person})}/>}
      {tab==="profile"&&<Profile profile={profile} onEdit={()=>setEditing(true)} onLogout={api.logout}/>}
      {tab==="admin"&&<Admin/>}
    </main>
    <nav><button className={tab==="discover"?"active":""} onClick={()=>setTab("discover")}><Search/><span>Discover</span></button><button className={tab==="matches"?"active":""} onClick={()=>setTab("matches")}><MessageCircle/><span>Matches</span></button><button className={tab==="profile"?"active":""} onClick={()=>setTab("profile")}><User/><span>Profile</span></button></nav>
    {editing&&<ProfileEditor profile={profile} onSave={setProfile} onClose={()=>setEditing(false)}/>}
  </div>
}

export default App;