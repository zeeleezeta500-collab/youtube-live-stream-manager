# Admin setup

V4 intentionally does not make a client-side email address an admin.

Use Firebase Admin SDK (Cloud Functions or a trusted server) to set:

`admin: true`

as a custom claim on the admin user's Firebase Auth account.

Then use rules such as:

`request.auth.token.admin == true`

for admin-only Firestore operations.

Do not put a Firebase Admin SDK service-account private key in Replit frontend code or Vite environment variables exposed to the browser.
