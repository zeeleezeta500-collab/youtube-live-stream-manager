<?php
if (!defined('ABSPATH')) exit;
function swipematch_enqueue(){
 wp_enqueue_style('swipematch-style',get_stylesheet_uri(),[], '4.0.0');
 wp_enqueue_script('firebase-app','https://www.gstatic.com/firebasejs/10.12.5/firebase-app-compat.js',[],null,true);
 wp_enqueue_script('firebase-auth','https://www.gstatic.com/firebasejs/10.12.5/firebase-auth-compat.js',['firebase-app'],null,true);
 wp_enqueue_script('firebase-firestore','https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore-compat.js',['firebase-app'],null,true);
 wp_enqueue_script('firebase-storage','https://www.gstatic.com/firebasejs/10.12.5/firebase-storage-compat.js',['firebase-app'],null,true);
 wp_enqueue_script('swipematch-app',get_template_directory_uri().'/assets/app.js',['firebase-auth','firebase-firestore','firebase-storage'],'4.0.0',true);
} add_action('wp_enqueue_scripts','swipematch_enqueue');
function swipematch_config(){return ['apiKey'=>get_theme_mod('sm_api_key',''),'authDomain'=>get_theme_mod('sm_auth_domain',''),'projectId'=>get_theme_mod('sm_project_id',''),'storageBucket'=>get_theme_mod('sm_storage_bucket',''),'messagingSenderId'=>get_theme_mod('sm_sender_id',''),'appId'=>get_theme_mod('sm_app_id','')];}
function swipematch_customize($c){$c->add_section('sm_firebase',['title'=>'SwipeMatch Firebase','priority'=>30]);$f=['sm_api_key'=>'Firebase API Key','sm_auth_domain'=>'Firebase Auth Domain','sm_project_id'=>'Firebase Project ID','sm_storage_bucket'=>'Firebase Storage Bucket','sm_sender_id'=>'Firebase Messaging Sender ID','sm_app_id'=>'Firebase App ID'];foreach($f as $id=>$label){$c->add_setting($id,['default'=>'','sanitize_callback'=>'sanitize_text_field']);$c->add_control($id,['label'=>$label,'section'=>'sm_firebase','type'=>'text']);}} add_action('customize_register','swipematch_customize');
function swipematch_shortcode(){ob_start();?><div id="swipematch-root" data-config="<?php echo esc_attr(wp_json_encode(swipematch_config())); ?>"><div class="sm-auth"><div class="sm-card"><h1 class="sm-logo">♥ <span>SwipeMatch</span></h1><p>Loading…</p></div></div></div><?php return ob_get_clean();} add_shortcode('swipematch_app','swipematch_shortcode');
function swipematch_setup(){add_theme_support('title-tag');add_theme_support('post-thumbnails');} add_action('after_setup_theme','swipematch_setup');
