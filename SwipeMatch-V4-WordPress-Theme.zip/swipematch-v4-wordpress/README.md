# SwipeMatch V4 WordPress Theme

1. WordPress Admin → Appearance → Themes → Add New → Upload Theme.
2. Upload the ZIP and activate it.
3. Create a page and add `[swipematch_app]`.
4. Go to Appearance → Customize → SwipeMatch Firebase.
5. Enter your Firebase Web App config values.
6. Enable Firebase Email/Password + Google Auth, Firestore and Storage.
7. Publish firebase/firestore.rules and firebase/storage.rules.

This is a functional Firebase-connected foundation. Before public launch, add App Check, server-side admin claims, rate limiting, moderation, account deletion, legal pages and security testing.
